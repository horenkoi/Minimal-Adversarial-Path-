%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clc
clear all
close all
addpath('ProgramFiles/')

%% Set the vector D with the number 
%% of non-informative uniformly-distributed feature dimensions 
%% (standard D=0)

D=0;%[0 1 8 16 32 64 128 256 512 1024];
rng('default')
rand('seed',1)
randn('seed',1)

%% Set the vector Turn with the number 
%% of double-spiral turns
%% (standard Turn=2)

Turn=2;%1:0.5:5.5;
Delta_Grid=[0.95];
for i_prop=1:length(Turn)
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
    Turn(i_prop)
    %[X,Pi]=generate_challenge1(50,5,D(i_prop));
    [X,Pi] = SwissRollClassifyData_v2(D,513,Turn(i_prop));
    %X(3:(D(i_prop)+2),:)=X(3:(D(i_prop)+2),randperm(size(X,2)));
    pi=Pi;

     %ind_perm_d=randperm(2+D(i_prop));
     %[~,ind_back_d]=sort(ind_perm_d,'ascend');
     %X=X(ind_perm_d,:);
    
    %X=[X;sin(X)];
    X0=0*X(:,1);
    %pi=pi(1:3,1:300);X=X(:,1:300);

    %[~,ii]=sort(pi(1,:),'descend');
    %pi=pi(:,ii(1:1000));
    %X=X(:,ii(1:1000));

    for d=1:size(X,1);
        mmin(d)=min(X(d,:));
        X(d,:)=X(d,:)-mmin(d);
        X0(d)=X0(d)-mmin(d);
        mmax(d)=max(abs(X(d,:)));
        %X(:,d)=csvresult1year(:,d);
        if mmax(d)>0
            X(d,:)=X(d,:)./mmax(d);
            X0(d)=X0(d)./mmax(d);
            % [D] = fitdist(X(d,:)','Kernel','Kernel','epanechnikov');
            % [D] = fitdist(X(d,:)', 'GeneralizedExtremeValue');
            % X(d,:) = cdf(D,X(d,:)')';
            % X0(d) = cdf(D,X0(d));
            % [D] = fitdist(X(d,:)', 'normal');
            % X(d,:) = cdf(D,X(d,:)')';
            % X0(d) = cdf(D,X0(d));
        end

    end

    X_orig=X;pi_orig=pi;


    rand('seed',1);
    randn('seed',1);

    warning('off','all')
    %% Set this flag to 1 if you have the licence for a "Parallel Computing" toolbox of MATLAB
    flag_parallel=1;
    %% Set this flag to 1 if you would like to train the Deep Learning classifier and have a
    %% "Deep Learning" toolbox licence of MATLAB
    flag_DL=0;
    %% Load the feature matrix X and matrix of label probabilities pi
    %load('classification_WDBC.mat')
    %% Number of eSPA patterns/boxes/clusters
    if Turn(i_prop)<=0.5
        K=6;
    elseif and(Turn(i_prop)<=1,Turn(i_prop)>0.5)
        K=11;
    elseif and(Turn(i_prop)<=1.5,Turn(i_prop)>1)
        K=35;
    elseif and(Turn(i_prop)<=2,Turn(i_prop)>1.5)
        K=55;
    elseif and(Turn(i_prop)>2,Turn(i_prop)<=2.5)
        K=250;
    elseif and(Turn(i_prop)>2.5,Turn(i_prop)<=3)
        K=350;
    elseif and(Turn(i_prop)>3,Turn(i_prop)<4)
        K=500
    else
        K=510;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    reg_param_W_espa=[1e-6 1e-5 6e-5 1e-4 2e-4 4e-4 6e-4 8e-4 1e-3 2e-3 4e-3 6e-3];
    reg_param_CL_espa=[1e-6 1e-5 5e-5 1e-4 2e-4 5e-4 8e-4 1e-3 2e-3 5e-3 1e-2 0.05 0.1 1];
    %reg_param_W_espa=[1e-4 1e3];
    %reg_param_CL_espa=[1e-8 2e-8 5e-8 1e-7 5e-7 1e-6 5e-6 1e-5 5e-5 1e-4 5e-4 1e-3];


    %reg_param_W=[8e-4 2e-3 5e-3 8e-3];
    %reg_param_CL=[1e-7];
    %reg_param_EPS=[5e-5 1e-4 1e-3 1e-2 1e-1  1e-2 1e3];

    T=size(X,2);
    %% Number of annealing steps to avoid trapping in the local optimum
    %% (take it as Number_of_Parallel_Cores*N, where N is any positive integer)
    N_anneal=1;
    %% Select flag_AUC=1 to use Area Under Curve as a performance metrics
    %% selecting flag_AUC=0 implies an Accuracy as a performance metrics
    flag_AUC=1;
    %%
    fraction=0.5;
    %% Normalize the data and make it dimensionless
    %ind=[];
    %for i=1:size(X,1)
    %    X(i,:)=X(i,:)-mean(X(i,:));
    %    if max(abs(X(i,:)))==0;
    %        ind=[ind i];
    %    else
    %        X(i,:)=X(i,:)/max(abs(X(i,:)));
    %    end
    %end
    clear reg_param 
    k=1;
    for i=1:length(reg_param_W_espa)
        for j=1:length(reg_param_CL_espa)
            reg_param(:,k)=[reg_param_W_espa(i);reg_param_CL_espa(j)];
            k=k+1;
        end
    end
    paroptions = statset('UseParallel',true);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %i_prop=1;
    for i_ann=1:N_anneal
        ind_perm=randperm(T);
        [~,ind_back]=sort(ind_perm,'ascend');
        X=X(:,ind_perm);
        pi=pi(:,ind_perm);
        X_train=X(:,1:floor(fraction*T));pi_train=pi(:,1:floor(fraction*T));
        %% Perform a random mislabeling of the training data
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        X_valid=X(:,(1+floor(fraction*T)):T);pi_valid=pi(:,(1+floor(fraction*T)):T);
        %X_valid(3:(D(i_prop)+2),:)=X_valid(3:(D(i_prop)+2),randperm(size(X_valid,2)));
        %X_train(3:(D(i_prop)+2),:)=X_train(3:(D(i_prop)+2),randperm(size(X_train,2)));

        %% Set a grid of EOS-SPA model parameters
        %reg_param_W=[1e-3 1e-2 1e-1 100];

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        seed=rng;
        n=1;
        while n<=4
            out_eSPA = SPACL_kmeans_dim_entropy_analytic_v3_ts(X_train,pi_train,...
                K,30,[],reg_param,X_valid,pi_valid,1,flag_AUC,flag_parallel);
            test_e=-out_eSPA.L_pred_valid_Markov
            pi_eSPA=EvaluateProbability_eSPA_full(X_orig,out_eSPA);
            [~,~,~,full_e] = perfcurve(logical(pi_orig(1,:)),pi_eSPA(1,:),1)
            if n==1
                eSPA_AUC(i_prop,i_ann)=test_e;
                eSPA_AUC_full(i_prop,i_ann)=full_e;
                eSPA{i_prop,i_ann}=out_eSPA;
            else
                if test_e>eSPA_AUC(i_prop,i_ann)
                    eSPA_AUC(i_prop,i_ann)=test_e;
                    eSPA_AUC_full(i_prop,i_ann)=full_e;
                    eSPA{i_prop,i_ann}=out_eSPA;
                end
            end
            n=n+1;
        end
        W{i_prop,i_ann}=eSPA{i_prop,i_ann}.W;
        N_param_eSPA(i_prop,i_ann)=((sum(eSPA{i_prop,i_ann}.W>1e-3)+1)*size(out_eSPA.P,2));
        t_eSPA(i_prop,i_ann)=eSPA{i_prop,i_ann}.time_Markov;
        eps_W(i_prop,i_ann)=eSPA{i_prop,i_ann}.reg_param_W
        eps_CL(i_prop,i_ann)=eSPA{i_prop,i_ann}.reg_param_CL
        ind_subsamp=randperm(T);ind_subsamp=ind_subsamp(1:min(200,T));
        %[mad]=MAD_eSPA_exact(out_eSPA,1:size(X,1),1,X(:,ind_subsamp),Delta_Grid);
        %[MAD0_eSPA(:,i_prop,i_ann),X0_delta{i_prop,i_ann}]=MAD_eSPA_exact(out_eSPA,1:size(X,1),1,X0,Delta_Grid);
        %MAD_eSPA(:,i_prop,i_ann)=nanmean(mad');

        %         if flag_AUC==1
        %             disp(['eSPA: AUC on validation data ' num2str(-out_eSPA.L_pred_valid_Markov) ', computational time ' num2str(out_eSPA.time_Markov) ' seconds, has ' num2str(max(out_eSPA.N_params_Markov)) ' tuneable parameters']);
        %         else
        %             disp(['eSPA: Accuracy on validation data ' num2str(-out_eSPA.L_pred_valid_Markov) ', computational time ' num2str(out_eSPA.time_Markov) ' seconds, has ' num2str(max(out_eSPA.N_params_Markov)) ' tuneable parameters']);
        %         end
        %         figure;plot(out_eSPA.W,'.:','LineWidth',2,'MarkerSize',9);
        %         xlabel('Feature Index, d');
        %         ylabel('eSPA Feature Weight, W(d)')
        %         set(gca,'FontSize',20,'LineWidth',2);
        %
        %         figure;imagesc(out_eSPA.gamma_valid);caxis([0 1]);title('Probablities P(i,t) for validation data to belong to eSPA patterns')
        %         xlabel('Validation Data Index, t');
        %         ylabel('eSPA Pattern Index, i')
        %         set(gca,'FontSize',20,'LineWidth',2);
        %         set(gcf,'Position',[10 100 800  600])
        %
        %         figure;subplot(2,1,1);
        %         plot(out_eSPA.P_valid(1,:),'.:','LineWidth',2,'MarkerSize',9)
        %         caxis([0 1]);ylabel('Probablity of Label=1')
        %         xlabel('eSPA Pattern Index, i');
        %         set(gca,'FontSize',20,'LineWidth',2);xlim([0.5 size(out_eSPA.C,2)+0.5])
        %         subplot(2,1,2);
        %         clear C
        %         for d=1:length(out_eSPA.W);
        %             C(d,:)=out_eSPA.W(d)*out_eSPA.C(d,:);
        %         end
        %         imagesc(C)
        %         ylabel('Feature Index,d')
        %         xlabel('eSPA Pattern Index, i');
        %         zlabel('Value')
        %         set(gca,'FontSize',20,'LineWidth',2);
        %         set(gcf,'Position',[10 100 800  600])
        %CMdl = fitctree(X_train',pi_train(1,:)');
        tic;
        CMdl=fitcensemble(X_train',logical(pi_train(1,:)'),'OptimizeHyperparameters','all');
        %CMdl = TreeBagger(150,X_train',logical(pi_train(1,:)'),'Method','r','OOBVarImp','on', ...
        %    'MinLeafSize',1,'Options',paroptions,'Method','classification');
        Ynew = predict(CMdl,X_valid');
        imp_RF{i_prop,i_ann} = predictorImportance(CMdl);
        [~,~,~,AUC_RF(i_prop,i_ann)] = perfcurve(logical(pi_valid(1,:)),double(Ynew)',1)
        s=whos("CMdl");
        N_param_RF(i_prop,i_ann)=s.bytes/16/3;
        close all
        t_RF(i_prop,i_ann)=toc;

        [out_glm] = LogitRegressionCross_v2(X_train,full(pi_train),X_valid,full(pi_valid));
        t_GLM_L1(i_prop,i_ann)=out_glm.time;
        AUC_GLM_L1(i_prop,i_ann)=out_glm.L_pred_valid
        [out_lda] = LDA(X_train,pi_train,X_valid,pi_valid);
        t_LDA(i_prop,i_ann)=out_lda.time;
        AUC_LDA(i_prop,i_ann)=out_lda.L_pred_valid

        tic;
        Mdl = fitcsvm(X_train',pi_train(1,:)','KernelFunction','polynomial');
        Ynew = predict(Mdl,X_valid');
         N_param_SVM(i_prop,i_ann)=d+1;
        [~,~,~,AUC_SVM(i_prop,i_ann)] = perfcurve(full(pi_valid(1,:)),double(Ynew)',1)
        t_SVM(i_prop,i_ann)=toc;

        
        
        [out_net]= ShallowNN_Classify_ts(X_train,pi_train, X_valid, pi_valid,flag_AUC);
        [~,ii]=max(out_net.L_pred_valid);
         N_param_PERC(i_prop,i_ann)=(2*d+1)*(out_net.num_neurons{ii(1)});
        AUC_PERC(i_prop,i_ann)= out_net.L_pred_valid_ts(ii(1))
        t_PERC(i_prop,i_ann)=out_net.time(ii(1));
        %%%
        % [~,yy] = predict(CMdl,X(:,ind_subsamp)');y=yy(:,1)';
        % pi_eSPA=EvaluateProbability_eSPA_full(X(:,ind_subsamp),out_eSPA);pi_eSPA=pi_eSPA(1,:);
        % %out_eSPA.P_valid*out_eSPA.gamma_valid;y_espa=pi_eSPA(1,:);
        % [MAD_grid_espa(:,i_prop,i_ann),MAD_grid_std_espa] = MAD_Data(X(:,ind_subsamp),pi_eSPA,[0.05:0.05:0.3]);
        % [MAD_grid_rf(:,i_prop,i_ann),MAD_grid_std_rf] = MAD_Data(X(:,ind_subsamp),y,[0.05:0.05:0.3]);
        %y_nn = net(X(:,ind_subsamp));
        %[MAD_grid_nn(:,i_prop,i_ann),MAD_grid_std_nn] = MAD_Data(X(:,ind_subsamp),y_nn,[0.05:0.05:0.3]);
        %
        % figure;plot(MAD_grid_espa);hold on;plot(MAD_grid_nn,'r--');plot(MAD_grid_rf,'g-o');
        if flag_DL==1
            %% From here you will need the "Deep Learning" Toolbox of MATLAB

            out_DL= DeepNN_Classify(X_train,pi_train, X_valid, pi_valid,flag_AUC);
            [~,i]=max(-out_DL.L_pred_valid);
            LSTM_AUC(i_prop,i_ann)=max(-out_DL.L_pred_valid(i))
            t_LSTM(i_prop,i_ann)=out_DL.time(i);
            %             if flag_AUC==1
            %                 disp(['Deep Learning (LSTM): AUC on validation data ' num2str(max(-out_DL.L_pred_valid(i))) ', computational time ' num2str(max(out_DL.time(i))) ' seconds, has ' num2str(max(out_DL.N_params(i))) ' tuneable parameters']);
            %             else
            %                 disp(['Deep Learning (LSTM): Accuracy on validation data ' num2str(max(-out_DL.L_pred_valid(i))) ', computational time ' num2str(max(out_DL.time(i))) ' seconds, has ' num2str(max(out_DL.N_params(i))) ' tuneable parameters']);
            %             end
            %             disp(['Deep Learning (LSTM) is here ' num2str(max(out_DL.time(length(out_DL.time)))/out_eSPA.time_Markov)...
            %                 ' times more costly then eSPA']);
            %
            %             out_DL.net{i}.Layers
        else
            out_DL=[];
        end
    end
end

out_eSPA=eSPA{1,1};
ind_rand=randperm(T);
N=100;
X0=X(:,ind_rand(1:N));
%X0=rand(2,N);
%X0=[0.2612;0.6458];%[0.1851; 0.7262];%
Delta=0.1;
ind_control=1:2;figure;
c_mean=0.5;
X=[X_train X_valid];pi=[pi_train pi_valid];
pi=EvaluateProbability_eSPA_full(X,out_eSPA);
ii1=find(pi(1,:)>=0.5);ii2=find(pi(1,:)<0.5);
hold on; plot(X(1,ii1),X(2,ii1),'b.','MarkerSize',10);plot(X(1,ii2),X(2,ii2),'r.','MarkerSize',10);
[~,MAD_espa,MAD_espa_mean,MAD_espa_std]=VisualizeVoronoi_v2(out_eSPA.C(ind_control,:),out_eSPA.P_valid(1,:),out_eSPA.W(ind_control,:),X0,Delta);
ii1=find(out_eSPA.P_valid(1,:)>0.5);ii2=find(out_eSPA.P_valid(1,:)<=0.5);
%plot(out_eSPA.C(ind_control(1),ii1),out_eSPA.C(ind_control(2),ii1),'rsq','LineWidth',3,'MarkerSize',12);
%plot(out_eSPA.C(ind_control(1),ii2),out_eSPA.C(ind_control(2),ii2),'b^','LineWidth',3,'MarkerSize',12);
% plot(X0_delta{i_prop,i_ann}(1,1),X0_delta{i_prop,i_ann}(1,2),'kx','LineWidth',3,'MarkerSize',12);
% plot(X0(1),X0(2),'kx','LineWidth',3,'MarkerSize',12);
title({['Best eSPA+' ' (' num2str(size(out_eSPA.P,2)) ' Voronoi cells,' num2str((sum(out_eSPA.W>1e-3)+1)*size(out_eSPA.P,2)) ' parameters, AUC=' num2str((round(-100*out_eSPA.L_pred_valid_Markov))/100) ')'],['MAD(X_0,0.5)=' num2str(round(10000*(MAD_espa_mean))/10000)]})
box on;
%colorbar
axis off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ind_control=1:2;figure;
[~,ii]=max(out_net.L_pred_valid);
X=[X_train X_valid];pi=[pi_train pi_valid];
pi=round(out_net.net{ii(1)}(X));
ii1=find(pi(1,:)==0);ii2=find(pi(1,:)==1);
hold on; plot(X(1,ii1),X(2,ii1),'b.','MarkerSize',10);plot(X(1,ii2),X(2,ii2),'r.','MarkerSize',10);

[~,MAD_NN,MAD_NN_mean,MAD_NN_std]=VisualizeANN(out_net.net{ii(1)},1:2,c_mean,X0,Delta);
ii1=find(out_eSPA.P_valid(1,:)>0.5);ii2=find(out_eSPA.P_valid(1,:)<=0.5);
% plot(X0_delta{i_prop,i_ann}(1,1),X0_delta{i_prop,i_ann}(1,2),'kx','LineWidth',3,'MarkerSize',12);
% plot(X0(1),X0(2),'kx','LineWidth',3,'MarkerSize',12);
title({['Best NN' ' (' num2str(out_net.num_neurons{ii(1)}) ' neurons,' num2str((2*d+1)*out_net.num_neurons{ii(1)}) ' parameters, AUC=' num2str(floor(100*out_net.L_pred_valid_ts(ii))/100) ')'],['MAD(X_0,0.5)=' num2str(round(10000*(MAD_NN_mean))/10000)]})
box on;
%colorbar
axis off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ind_control=1:2;figure;
X=[X_train X_valid];pi=[pi_train pi_valid];
pi=round(predict(CMdl,X'));

ii1=find(pi==0);ii2=find(pi==1);
hold on; plot(X(1,ii1),X(2,ii1),'b.','MarkerSize',10);plot(X(1,ii2),X(2,ii2),'r.','MarkerSize',10);
[~,MAD_RF,MAD_RF_mean,MAD_RF_std]=VisualizeRF(CMdl,1:2,c_mean,X0,Delta);
ii1=find(out_eSPA.P_valid(1,:)>0.5);ii2=find(out_eSPA.P_valid(1,:)<=0.5);
s=whos("CMdl");
% plot(X0_delta{i_prop,i_ann}(1,1),X0_delta{i_prop,i_ann}(1,2),'kx','LineWidth',3,'MarkerSize',12);
% plot(X0(1),X0(2),'kx','LineWidth',3,'MarkerSize',12);

%% Number of RF parameters is not provided by the MATLAB, to estimate it roughly we take the number 
%% floating point number in double precision that fit to the size of the RF object memory. Mimicking NN - where
%% the number of tuneable parameters is one third of this number of floating point numbers,
%% we divide this number by three to obtain a rough estimate.
box on;
%colorbar
axis off
title({['Best BRF' ' (' num2str(CMdl.NumTrained) ' trees, ' num2str(round(s.bytes/16/3)) ' parameters, AUC=' num2str((floor(100*AUC_RF(i_prop,i_ann)))/100) ')'],['MAD(X_0,0.5)=' num2str(round(10000*(MAD_RF_mean))/10000)]})
