
% Analytical evaluaton of the gamma-step (p. 1567 eSPA paper)

% Input - X: matrix containing the features
%		  pi: matrix containing the lables 
% 		  C: matrix of box coordinates 
% 		  Lambda: matrix of conditional probabilites 
% 		  T: size of the data statistic 
%		  K: number of discretization boxes
%		  m: number of labels
%		  d: number of features in the matrix X
%		  reg_param: matrix with the combination of the regularization parameters


function [gamma] = EOS_SPA_EvaluateGamma(X,pi,C,Lambda,T,K,d,reg_param,W,WT);
	
        W_m = sqrt(W)';
        %    % Pre-multiplication of W with X, analytic solution eSPA paper p.1567
        X_W = bsxfun(@times,X,W_m);  % element-wise multiplication              
        %end                

        % Pre-multiplication of W with C, analytic solution (eSPA paper p.1567)
        C_W = bsxfun(@times,C,W_m);     % element-wise multiplication

	% Computation of the gamma step (see p. 1567 eSPA paper) 	     % Why (1/d)?
	[~,idx] = min(-1 * reg_param * bsxfun(@times,log(max(Lambda',1e-12)) * pi,WT) + (1/(d)) * bsxfun(@times,sqDistance(X_W, C_W)',WT));

	% Initialization of the gamma vector
	gamma = zeros(K,T);

	% Checking if the condition of the analytical solution is met
	for k = 1:K
	    gamma(k,find(idx==k)) = 1;
	end 

end

