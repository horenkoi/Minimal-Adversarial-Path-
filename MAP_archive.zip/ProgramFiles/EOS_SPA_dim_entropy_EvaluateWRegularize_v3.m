
% Computation of the W-step

% Input - X: matrix containing the features
%         gamma: matrix of box probabilities
% 		  C: matrix of box coordinates 
%		  d: number of features in the matrix X
% 		  T: size of the data statistic 
%         W:  vector of feature probabilities 
%         WT: weights of data points
%         eps_C: value of the regularizzation parameter epsilon_C 

function [W] = EOS_SPA_dim_entropy_EvaluateWRegularize_v3(X,gamma,C,WT,eps_C,d)

	b = sum(bsxfun(@times,(X-C*gamma).^2,WT),2);
	z = exp(-b./(eps_C*d));

	% new improved version
	W = (z./sum(z))';

end


