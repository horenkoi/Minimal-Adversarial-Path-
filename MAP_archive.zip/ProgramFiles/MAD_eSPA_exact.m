function [mad,X0_delta,ind_kkk]=MAD_eSPA_exact(model,ind_control,label_control,X,Delta);
%X=sqrt(model.W)*X;
P=model.P_valid;
prob_X=EvaluateProbability_eSPA_full(X,model);
prob_X=prob_X(label_control,:);
[D,T]=size(X);
ii=1:size(P,2);
%find(P(label_control,:)<prob_margin);
H=2*spdiags(ones(length(ind_control),1),0,length(ind_control),length(ind_control));
sqrtW=sqrt(model.W);
%H=2*spdiags(sqrtW,0,length(ind_control),length(ind_control));

ppp=EvaluateProbability_eSPA_full(model.C,model);ppp=ppp(label_control,:);
options = optimoptions('quadprog','Algorithm','interior-point-convex','Display','off','MaxIterations',5000,'ConstraintTolerance',1e-9,'FunctionTolerance',1e-9);
%W=ones(size(W));
%W_m = sqrt(W);
%X_W=X.*W_m;
mad=zeros(length(Delta),T);
kkk=1;
for t=1:T
    %t
    %fprintf(['Computing MAD: ' num2str(round(t/T*100)) '%']);
    for k=1:size(model.C,2)
        n(k)=norm(X(:,t)-model.C(:,k),"fro")^2;
    end
    [~,KK]=min(n);
    %f=-2*diag(sqrtW)*X(ind_control,t);
    f=-2*X(ind_control,t);
    x=zeros(KK-1,D);dist=[];risk=[];
    ind=1;
    clear prob dist
    for i=setdiff(1:length(ii),KK)
        [A,b]=ComputeBoundingPlanesofSimplex(model,ii(i),ind_control,X);
        [xx,fval,exitflag,output] = quadprog(H,f,A,b,[],[],zeros(length(ind_control),1),ones(length(ind_control),1),model.C(ind_control,ii(i)),options);
        if isempty(xx)
           xx=X(ind_control,t);
        end
        if or(exitflag<=-1,norm(X(ind_control,t)-xx,"fro")^2<1e-8)
            %'keyboard'
            %keyboard
            flag(t,i)=0;
        else
            %t
            flag(t,i)=1;
            x(ind,:)=(X(:,t)');
            x(ind,ind_control)=(xx);
            %dist(ind)=norm(diag(sqrtW(ind_control))*(X(ind_control,t)-xx),"fro")^2;
            dist(ind)=norm(X(ind_control,t)-xx,"fro")^2;
            prob(ind)=ppp(i);
            %x(ind,:)=x(ind,:).ind/W_m';
            ind=ind+1;
        end
    end
    if sum(flag(t,:))>0
        for i_d=1:length(Delta)
            % if and(t==92,i_d==10)
            %     i_d
            %     t
            %     keyboard
            % end
            [~,ll]=find(abs(prob_X(t)-prob)>Delta(i_d));
            if ~isempty(ll)
                [~,jj]=min(dist(ll));
                mad(i_d,kkk)=dist(ll(jj(1)));
                X0_delta(:,i_d,kkk)=x(ll(jj(1)),:);
            else
                mad(i_d,kkk)=NaN;
            end
        end
        ind_kkk{kkk}=t;
        kkk=kkk+1;
    end

end
