function [X0,MAD_logit,prob_change] = MAD_logit(beta,X,ind_control,Delta)
% MAD for logit regression P=1/(1+exp(-beta'*X))

options = optimoptions('quadprog','Algorithm','interior-point-convex','Display','off','MaxIterations',5000,'ConstraintTolerance',1e-9,'FunctionTolerance',1e-9);
[D,T]=size(X);
ind_control=ind_control;
H=2*spdiags(ones(length(ind_control),1),0,length(ind_control),length(ind_control));
for d=1:length(ind_control)
    mind(d)=min(X(ind_control(d),:));
    maxd(d)=max(X(ind_control(d),:));
end
ind_other=setdiff(1:(D+1),ind_control+1);
for t=1:T
    t
    XX=[1;X(:,t)];
    px=1./(1+exp(-beta'*XX));
    %t
    %fprintf(['Computing MAD: ' num2str(round(t/T*100)) '%']);
    if (px-Delta)>=0
        f=-2*X(ind_control,t);
        A=beta(ind_control+1)';b=-log(1/(px-Delta)-1)-beta(ind_other)'*XX(ind_other);
        [x0,fval,exitflag,output] = quadprog(H,f,A,b,[],[],mind,maxd,X(ind_control,t),options);
        if exitflag>-1
            X0(:,t)=X(:,t); X0(ind_control,t)=x0;
            MAD_logit(t)=norm(X(ind_control,t)-x0,"fro")^2;
            prob_change(t)=px-1./(1+exp(-beta'*[1;X0(:,t)]));
        else
            X0(:,t)=nan.*X(:,t);
            MAD_logit(t)=nan;
            prob_change(t)=nan;
        end
    else
        X0(:,t)=nan.*X(:,t);
        prob_change(t)=nan;
        MAD_logit(t)=nan;
    end
end

end