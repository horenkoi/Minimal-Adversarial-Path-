function Y = inv_cdf(D,X)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
for d=1:numel(D)
    %d
    Y(d)=icdf(D{d},X(d));
end
end