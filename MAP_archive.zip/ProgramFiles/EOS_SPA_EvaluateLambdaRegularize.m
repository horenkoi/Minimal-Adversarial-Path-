
% Computation of Lambda using the formula Pi*gamma

% Input - pi: matrix containing the lables
%		  gamma: matrix of box probabilities
%		  m: number of labels
%		  K: number of discretization boxes

function [Lambda]=EOS_SPA_EvaluateLambdaRegularize(pi,gamma,m,K,WT);

    pi=bsxfun(@times,pi,WT); 
    Lambda = pi * gamma';

    % Compute the analytical solution for each geometrix box
    for k = 1:K
        ss = sum(Lambda(:,k));
        if ss > 0
        	Lambda(:,k) = Lambda(:,k) ./ sum(Lambda(:,k));
        else
        	Lambda(:,k)=1/m;   
        end
    end

end

