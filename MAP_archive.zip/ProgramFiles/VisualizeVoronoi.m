function []=VisualizeVoronoi(C,P)

C=C(1:2,:);
%C=D(:,size(D,1)-1:size(D,1))'*Centroids;
%figure;hold on;
N_grid=100;delta=0.1;
%[XX,YY]=meshgrid((min(C(1,:))-delta):(max(C(1,:))-min(C(1,:))+2*delta)/N_grid:max(1,(max(C(1,:))+delta)),(min(C(2,:))-delta):(max(C(2,:))-min(C(2,:))+2*delta)/N_grid:max((max(C(2,:))+delta),1));
[XX,YY]=meshgrid(0:1/N_grid:1,0:1/N_grid:1);
xx=reshape(XX,1,numel(XX));yy=reshape(YY,1,numel(YY));
[~,idx] = min(sqDistance([xx; yy;repmat(mean(C(3:size(C,1),:)')',1,length(xx))], C)');
zz=0*xx;
for t=1:length(idx)
zz(t)=P(idx(t));%round(P(idx(t))*100)/100;
end
[~, contourObj]=contourf(XX,YY,reshape(zz,size(XX,1),size(XX,2)),P);
% This is the secret that 'keeps' the transparency.
eventFcn = @(srcObj, e) updateTransparency(srcObj);
addlistener(contourObj, 'MarkedClean', eventFcn);

h = voronoi(C(1,:)',C(2,:)');hold on;
%for t=1:size(C,2)
% text(C(1,t)+0.005,C(2,t)+0.005,[num2str(t)],'FontSize',24);
% end
h(1).MarkerSize=15;h(1).Marker='none';h(1).MarkerFaceColor='k';
set(h(2:end),{'linew'},{2});set(h(2:end),{'color'},{'r'});set(h(2:end),{'linestyle'},{':'})
set(gcf,'Position',[10 100 800  600]);
set(gca,'FontSize',24,'LineWidth',2);
%axis off
%colormap jet
caxis([0 1])
end
function updateTransparency(contourObj)
contourFillObjs = contourObj.FacePrims;
for i = 1:length(contourFillObjs)
    % Have to set this. The default is 'truecolor' which ignores alpha.
    contourFillObjs(i).ColorType = 'truecoloralpha';
    % The 4th element is the 'alpha' value. First 3 are RGB. Note, the
    % values expected are in range 0-255.
    contourFillObjs(i).ColorData(4) = 30;
end
end
