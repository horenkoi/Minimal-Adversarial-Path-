function [obj]=FindVoronoiGraphSPA(model,ind_control,label_control,X,monoton_flag);
P=model.P_valid;
H=4*eye(length(ind_control));

prob_X=EvaluateProbability_eSPA_full(X,model);
Ws=sqrt(model.W(ind_control));
ii=1:size(P,2);%find(P(label_control,:)<prob_margin);
%f=zeros(1,length(ind_control));
options = optimoptions('quadprog','Algorithm','interior-point-convex','Display','off','MaxIterations',10000,'ConstraintTolerance',1e-12,'FunctionTolerance',1e-12);
%options = optimoptions('linprog','Algorithm','dual-simplex','Display','none','MaxIterations',10000,'ConstraintTolerance',1e-9);
obj.adj=zeros(length(ii));
facet_ind=length(ii)+1;
for i=1:length(ii)
    %i
    ppp=EvaluateProbability_eSPA_full(model.C(:,i),model);
    obj.W(i)=ppp(label_control);
    [Ai,bi]=ComputeBoundingPlanesofSimplex(model,ii(i),ind_control,X);
    obj.pos(:,i)=X;
    obj.pos(ind_control,i)=model.C(ind_control,i);

    for j=1:length(ii)
        %obj.adj(i,j)=0;
        f=-2*(model.C(ind_control,j)+model.C(ind_control,i));
        [Aj,bj]=ComputeBoundingPlanesofSimplex(model,ii(j),ind_control,X);
        [xx,fval,exitflag,output] = quadprog(H,f,[Ai;Aj],[bi;bj],[],[],zeros(length(ind_control),1),ones(length(ind_control),1),model.C(ind_control,ii(i)),options);
        pppj=EvaluateProbability_eSPA_full(model.C(:,j),model);
        %if and(i==37,j==4)
        %    keyboard;
        %end
        if monoton_flag==0
            if and(exitflag>0,pppj(label_control)>=obj.W(i));
                flag=1;
                for kkk=1:size(obj.pos,2)
                    if norm(Ws.*obj.pos(ind_control,kkk)-Ws.*(0.5*model.C(ind_control,j)+0.5*model.C(ind_control,i)),2)<1e-5
                        flag=0;
                    end
                end
                if norm(Ws.*xx-Ws.*(0.5*model.C(ind_control,j)+0.5*model.C(ind_control,i)),2)<1e-5
                    dist=norm(Ws.*(model.C(ind_control,j)-model.C(ind_control,i)),2);
                    obj.adj(j,i)=dist;%obj.adj(j,i)=dist;
                else
                    obj.adj(j,i)=0;
                end
                if (flag==1)
                    % if i>j
                    dist_i=norm(Ws.*(xx-model.C(ind_control,i)),2);
                    if pppj(label_control)==obj.W(i)
                        obj.adj(i,facet_ind)=dist_i;%obj.adj(j,i)=dist;
                    end
                    obj.adj(facet_ind,i)=dist_i;%obj.adj(j,i)=dist;
                    dist_j=norm(Ws.*(xx-model.C(ind_control,j)),2);
                    if pppj(label_control)==obj.W(i)
                        obj.adj(facet_ind,j)=dist_j;%obj.adj(j,i)=dist;
                    end
                    obj.adj(j,facet_ind)=dist_j;%obj.adj(j,i)=dist;
                    obj.W(facet_ind)=0.5*obj.W(i)+0.5*pppj(label_control);
                    obj.pos(:,facet_ind)=X;
                    obj.pos(ind_control,facet_ind)=xx;
                    facet_ind=facet_ind+1;
                    %end
                end
                %             elseif and(exitflag>0,pppj(label_control)<=obj.W(i));
                %                 flag=1;
                %                 for kkk=1:size(obj.pos,2)
                %                     if norm(Ws.*obj.pos(ind_control,kkk)-Ws.*(0.5*model.C(ind_control,j)+0.5*model.C(ind_control,i)),2)<1e-5
                %                         flag=0;
                %                     end
                %                 end
                %                 if norm(Ws.*xx-Ws.*(0.5*model.C(ind_control,j)+0.5*model.C(ind_control,i)),2)<1e-5
                %                     dist=norm(Ws.*(model.C(ind_control,j)-model.C(ind_control,i)),2);
                %                     obj.adj(i,j)=dist;%obj.adj(j,i)=dist;
                %                 else
                %                     obj.adj(i,j)=0;
                %                 end
                %                 if (flag==1)
                %                     % if i>j
                %                     dist_i=norm(Ws.*(xx-model.C(ind_control,i)),2);
                %                     if pppj(label_control)==obj.W(i)
                %                         obj.adj(i,facet_ind)=dist_i;%obj.adj(j,i)=dist;
                %                     end
                %                     obj.adj(facet_ind,i)=dist_i;%obj.adj(j,i)=dist;
                %                     dist_j=norm(Ws.*(xx-model.C(ind_control,j)),2);
                %                     if pppj(label_control)==obj.W(i)
                %                         obj.adj(j,facet_ind)=dist_j;%obj.adj(j,i)=dist;
                %                     end
                %                     obj.adj(facet_ind,j)=dist_j;%obj.adj(j,i)=dist;
                %                     obj.W(facet_ind)=0.5*obj.W(i)+0.5*pppj(label_control);
                %                     obj.pos(:,facet_ind)=X;
                %                     obj.pos(ind_control,facet_ind)=xx;
                %                     facet_ind=facet_ind+1;
                %                     %end
                %                 end
            end

        end
    end
end
if size(obj.adj,1)<size(obj.adj,2)
    obj.adj=[obj.adj;zeros(size(obj.adj,2)-size(obj.adj,1),size(obj.adj,2))];
end
if size(obj.adj,2)<size(obj.adj,1)
    obj.adj=[obj.adj zeros(size(obj.adj,1),size(obj.adj,1)-size(obj.adj,2))];
end