%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Vuisualisation of the eSPA Voronoi diagramm in 2D
%%
%% (c) Illia Horenko 2022, GNU General Public License v2.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function []=VisualizeVoronoi_v4(C,P,W,ind,x0)
%% C - cluster centers
%% P - vector wiith eSPA label probabilities for cluusters
%% W - vector of eSPA dimension weights
%% ind - indices two dimensions to visuualize
%% x0 - point of Voronoi projection
%C=C(ind,:);
N_grid=100;
[XX,YY]=meshgrid(min(C(ind(1),:)):(max(C(ind(1),:))-min(C(ind(1),:)))/N_grid:max(C(ind(1),:)),min(C(ind(2),:)):(max(C(ind(2),:))-min(C(ind(2),:)))/N_grid:max(C(ind(2),:)));
xx=reshape(XX,1,numel(XX));yy=reshape(YY,1,numel(YY));
ind_other=setdiff(1:size(C,1),ind);
xx_other=zeros(length(ind_other),length(xx));
for i=1:length(ind_other)
    xx_other(i,:)=x0(ind_other(i)).*ones(1,length(xx));
end


[~,idx] = min(sqrt(sqDistance(bsxfun(@times,sqrt(W),[xx; yy;xx_other]), bsxfun(@times,sqrt(W),C))'));
zz=0*xx;
for t=1:length(idx)
zz(t)=P(idx(t));
end
hold on;
[~, contourObj]=contourf(XX,YY,reshape(zz,size(XX,1),size(XX,2)),P);
set(gcf,'Position',[10 100 800  600]);
set(gca,'FontSize',24,'LineWidth',2);
%axis off
colormap jet
caxis([0 1])
end
function updateTransparency(contourObj)
contourFillObjs = contourObj.FacePrims;
for i = 1:length(contourFillObjs)
    % Have to set this. The default is 'truecolor' which ignores alpha.
    contourFillObjs(i).ColorType = 'truecoloralpha';
    % The 4th element is the 'alpha' value. First 3 are RGB. Note, the
    % values expected are in range 0-255.
    contourFillObjs(i).ColorData(4) = 30;
end
end
