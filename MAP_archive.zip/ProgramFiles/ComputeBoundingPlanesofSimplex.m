function [A,b]=ComputeBoundingPlanesofSimplex(model,k,ind_control,X); 

C=model.C;

W=model.W;
%W=ones(size(W));
W_m = sqrt(W);
C = bsxfun(@times,C,W_m);

[D,K]=size(C);
A=zeros(K-1,length(ind_control));
ind_other=setdiff(1:D,ind_control);
ind=1;
for i=setdiff(1:K,k)
    dS=(C(:,k)-C(:,i))./norm(C(:,k)-C(:,i),'fro');
    C_mid=C(:,i)+0.5*(C(:,k)-C(:,i));
    b(ind)=-dS'*C_mid+dS(ind_other)'*(W_m(ind_other).*X(ind_other,1));
    A(ind,:)=-bsxfun(@times,dS(ind_control),W_m(ind_control))';
    ind=ind+1;
end
%A=[A;-eye(length(ind_control));eye(length(ind_control))];b=[b';zeros(length(ind_control),1);ones(length(ind_control),1)];
b=b';