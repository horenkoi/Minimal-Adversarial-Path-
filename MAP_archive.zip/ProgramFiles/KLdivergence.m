

% Computation of the Kullback–Leibler divergence

% Input - x and y: two vectors with coherent dimensions

function [ KL ] = KLdivergence(x,y)

	[~,ix] = max(x);
	[~,iy] = max(y);
	KL = -(ix==iy) * size(x,1);

end

