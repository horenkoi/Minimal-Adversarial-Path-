function [p,chi2] = FischerTestGamma(out_eSPA,pi,Voronoi_box_index)

gamma_full=[out_eSPA.gamma(Voronoi_box_index,:) out_eSPA.gamma_valid(Voronoi_box_index,:)];
idx_gamma=1:length(gamma_full);
[confusion_matrix,chi2,p]=crosstab(gamma_full(idx_gamma),pi(1,idx_gamma));
[h,p,stats] = fishertest(confusion_matrix);
end