function [MAAD_grid,MAAD_grid_std] = MAAD_Data(Data,Y,delta_grid)
%%%%%%%%%%%%%%%%
Sample_Length=100;
%%%%%%%%%%%%%%%%
N=length(delta_grid);
D=size(Data,1);
D_inv=1./D;
for n=1:N
    n
    Delta=delta_grid(n);
    if Delta>0.5
    [~,i_start]=find(or(Y<Delta,Y>(1-Delta)));
    else
    [~,i_start]=find(or(Y<(1-Delta),Y>(Delta))); 
    end
    X_start=Data(:,i_start(1:min(Sample_Length,length(i_start))));
    Y_start=Y(:,i_start(1:min(Sample_Length,length(i_start))));

    %[~,Y] = predict(mdl,X');Y=Y(1);
    MAAD=zeros(1,size(X_start,2));
    for d_ind=1:size(X_start,2);
        for t=1:size(Data,2)
            dist(t)=D_inv*sum((X_start(d_ind)-Data(:,t)).^2);
        end
        % if and(n==6,d_ind==3)
        %     keyboard
        % end
        [~,ii]=find(abs(Y_start(d_ind)-Y)>=Delta);
        [~,jj]=min(dist(ii));
        MAAD(d_ind)=D_inv*dist(ii(jj(1)));
    end
    MAAD_grid(n)=mean(MAAD);
    MAAD_grid_std(n)=std(MAAD);
end