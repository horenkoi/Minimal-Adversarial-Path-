
% Computation of the squared distance

% Input - X and Y: matrices with coherent dimensions

function dist = isqDistance(X, Y)
for k=1:size(Y,2);
    dist(:,k)=sum(max(1e-7,abs(bsxfun(@minus, X , Y(:,k)))).^(-2))';
end;