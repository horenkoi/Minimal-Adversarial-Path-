function [MAP,MAD,mean_MAD,std_MAD]=VisualizeVoronoi_v2(C,P,W,X0,delta)

C=C(1:2,:);
%C=D(:,size(D,1)-1:size(D,1))'*Centroids;
%figure;hold on;
N_grid=2000;
%[XX,YY]=meshgrid((min(C(1,:))-delta):(max(C(1,:))-min(C(1,:))+2*delta)/N_grid:max(1,(max(C(1,:))+delta)),(min(C(2,:))-delta):(max(C(2,:))-min(C(2,:))+2*delta)/N_grid:max((max(C(2,:))+delta),1));
[XX,YY]=meshgrid(0:1/N_grid:1,0:1/N_grid:1);
xx=reshape(XX,1,numel(XX));yy=reshape(YY,1,numel(YY));

[~,idx] = min(sqrt(sqDistance(bsxfun(@times,sqrt(W),[xx; yy]), bsxfun(@times,sqrt(W),C))'));
zz=0*xx;
for t=1:length(idx)
zz(t)=P(idx(t));%round(P(idx(t))*100)/100;
end
X_input=[xx; yy];
[~,idx] = min(sqrt(sqDistance(bsxfun(@times,sqrt(W),X0(:,1)), bsxfun(@times,sqrt(W),C))'));
P0=P(idx);
[ind]=find(abs(zz-P0(1))>delta);
[MAD,ii]=min(sqDistance(X_input(:,ind), X0(:,1)));
MAP=X_input(:,ind(ii));

hold on;
[~, contourObj]=contourf(XX,YY,reshape(zz,size(XX,1),size(XX,2)),P);
% This is the secret that 'keeps' the transparency.
eventFcn = @(srcObj, e) updateTransparency(srcObj);
addlistener(contourObj, 'MarkedClean', eventFcn);

h = voronoi(C(1,:)',C(2,:)');hold on;
%for t=1:size(C,2)
% text(C(1,t)+0.005,C(2,t)+0.005,[num2str(t)],'FontSize',24);
% end
h(1).MarkerSize=15;h(1).Marker='none';h(1).MarkerFaceColor='k';
set(h(2:end),{'linew'},{2});set(h(2:end),{'color'},{'r'});set(h(2:end),{'linestyle'},{':'})
set(gcf,'Position',[10 100 800  600]);
set(gca,'FontSize',24,'LineWidth',2);
%axis off
%colormap jet
plot(X0(1,1),X0(2,1),'mo','MarkerSize',10,'LineWidth',4);
plot(MAP(1),MAP(2),'mx','MarkerSize',10,'LineWidth',4);
caxis([0 1])

for t=1:size(X0,2)
    [~,idx] = min(sqrt(sqDistance(bsxfun(@times,sqrt(W),X0(:,1)), bsxfun(@times,sqrt(W),C))')); 
    P0=P(idx);
    [ind]=find(abs(zz-P0(1))>delta);
    [MAD(t),~]=min(sqrt(sqDistance(X_input(:,ind), X0(:,t))));
end
mean_MAD=mean(MAD);
std_MAD=std(MAD-mean_MAD);
%colorbar east
end
function updateTransparency(contourObj)
contourFillObjs = contourObj.FacePrims;
for i = 1:length(contourFillObjs)
    % Have to set this. The default is 'truecolor' which ignores alpha.
    contourFillObjs(i).ColorType = 'truecoloralpha';
    % The 4th element is the 'alpha' value. First 3 are RGB. Note, the
    % values expected are in range 0-255.
    contourFillObjs(i).ColorData(4) = 30;
end
end
