function [] = MyBoxChart(xx,yy,boxes,col,mult,add);
BBB=length(boxes);
kk=1;
for t=1:BBB-1,
    ii=find(and(boxes(t)<xx,boxes(t+1)>=xx));
    if ~isempty(ii)
     stat{kk}=yy(ii)';
     m(kk)=mean(stat{kk});
     pd = fitdist(stat{kk},'Normal');
     ci = paramci(pd,'Alpha',.05);
     std_m(:,kk)=ci(:,1);
     name(kk)=(0.5*boxes(t)+0.5*boxes(t+1));
     kk=kk+1;
    end
end
years = name;
if nargin==6
years = name*mult+add;
end
%hold on;h=boxplotGroup(stat,'primaryLabels', years,'Colors',col);
hold on;errorbar(years,m,std_m(2,:)-m,m-std_m(1,:),'Color',col,'LineWidth',3)