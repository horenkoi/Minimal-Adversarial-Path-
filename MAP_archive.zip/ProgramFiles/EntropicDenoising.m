function out=EntropicDenoising(in)

X=in.X;
d=size(X,1);
T=size(X,2);
K=2;
alpha=in.alpha;
if isempty(in.C)
   ind=randperm(T);
   C = X(:,ind(1:K));
else
   C=in.C;
end

eps=1e-10;
MaxIter=200;
delta_L=1e10;
% Initialization of C
ind=randperm(T);
n_iter=1;
while and(delta_L>eps,n_iter<MaxIter)
    gamma=EntropicDenoising_gamma(X,C,K,alpha);
    [C,L(n_iter)]=EntropicDenoising_(X,gamma,K,T,d,alpha);
    if n_iter>1
       delta_L=L(n_iter-1)-L(n_iter); 
    end
    n_iter=n_iter+1;
end
out.C=C;
out.gamma=gamma;
out.L=L;
end

function gamma=EntropicDenoising_gamma(X,C,K,alpha)
    b=sqDistance(X, C)';
	z = exp(-(b(1,:)-b(2,:))./alpha);

	% new improved version
	gamma(1,:) = (z./sum(z))';
    gamma(2,:)=1-gamma(1,:);
end

function [C,L]=EntropicDenoising_(X,gamma,K,T,d,alpha);
	C = zeros(d,K); 
    N = sum(gamma',1);

 	for k = 1:K

		% Perform the sum for the numerator of the analytical solution
	    for t = 1:T
	        C(:,k) = C(:,k) + gamma(k,t)*X(:,t);
        end
        if N(k) > 0
	    	C(:,k) = C(:,k)./N(k);
	    else     % Is this a check for a division by zero? Is it even possible?
	    	C(:,k) = (1e-10)*randn(d,1);    
	    end

    end
    L= 1./T*(sum(sum(gamma.*sqDistance(X, C)'))+alpha*sum(gamma(1,:).*log(max(1e-12,gamma(1,:)))));

end

