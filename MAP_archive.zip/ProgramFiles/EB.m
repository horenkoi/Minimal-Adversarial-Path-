function [mu,mi,pl] = EB(DD,X,sym,ind_out_i,ind_out_j)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
X(X==0) = NaN;
[T,D]=size(X);
if nargin==5
for i=1:D  
    if sum(isnan(X(:,i)))<D
      if ind_out_i==i  
         dat=X(setdiff(1:T,ind_out_j),i);  
      else
         dat=X(:,i);   
      end    
      pd = fitdist(rmoutliers(dat),'Normal');
      ci = paramci(pd);
      mu(i)=pd.mu;
      pl(i)=ci(1,1)-mu(i);
      mi(i)=mu(i)-ci(2,1);
    else
      mu(i)=NaN;
      pl(i)=0;
      mi(i)=0;
    end
end
else
for i=1:D  
    if sum(isnan(X(:,i)))<D
      dat=X(:,i);   
      pd = fitdist(rmoutliers(dat),'Normal');
      ci = paramci(pd);
      mu(i)=pd.mu;
      pl(i)=ci(1,1)-mu(i);
      mi(i)=mu(i)-ci(2,1);
    else
      mu(i)=NaN;
      pl(i)=0;
      mi(i)=0;
    end
end

end    
hold on;errorbar(DD,mu,mi,pl,sym,'LineWidth',2);
end