function [X,Pi] = SwissRollClassifyData_v2(dim,T,Turn)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
pi=3.1415926;

r=(1/T)*[1:T];
theta=(Turn*2)*pi*(1/T)*[1:T];
X(1:2,1:T)=[r.*cos(theta);r.*sin(theta)];
X(1:2,(1+T):2*T)=[(r+0.2/Turn*2).*cos(theta);(r+0.2/Turn*2).*sin(theta)];
X=X+0.0*randn(2,2*T);
Pi(1,1:T)=1;Pi(1,(1+T):2*T)=0;
Pi(2,:)=1-Pi(1,:);
if dim>=1
X(3:(3+dim-1),:)=rand(dim,2*T);
end