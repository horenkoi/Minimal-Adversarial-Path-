function prob=Visualize1DSeSPA_Sensitivity(out_eSPA,ind,X,vis_flag,t,ind_prob,tt,TitleName)

%% ind - the feature index
%% X - the data point 
%% vis_flag - visualize plots yes/no
%% t - index of the data point (used only for visualization)
%% ind_prob - index of the class label probability to visualize
%% tt -feature grid for visualization 

prob_true=EvaluateProbability_eSPA_full(X,out_eSPA);
%tt=10.^[-7:0.01:0];
clear xxx
if length(ind)==1
for ind_t=1:length(tt); 
    xxx(:,ind_t)=X;
    xxx(ind,ind_t)=tt(ind_t);
end;
prob=EvaluateProbability_eSPA_full(xxx,out_eSPA);
if strcmp(vis_flag,'yes')
figure;semilogx(tt,prob(1,:),'-o','LineWidth',2);hold on;semilogx(X(ind),prob_true(1),'rx','MarkerSize',9,'LineWidth',3)
set(gca,'FontSize',20,'LineWidth',2);
set(gcf,'Position',[10 100 800  600]);
xlabel(['Value of the feature ' num2str(ind)]);ylabel({'Company default probability after','1 year'});
title(['Company ' num2str(t)]);
ylim([-0.05 1.05]);xlim([10^(-7.5) 1.1])
end
else
    tt1=tt;tt2=tt;
    xxx=zeros(size(X,1),length(tt).^2);
    k=1;
    for ind_t1=1:length(tt1);
        for ind_t2=1:length(tt2);
            xxx(:,k)=X;
            xxx(ind(1),k)=tt1(ind_t1);
            xxx(ind(2),k)=tt2(ind_t2);
            ind_i(k)=ind_t1;
            ind_j(k)=ind_t2;
            k=k+1;
        end;
    end
    prob=EvaluateProbability_eSPA_full(xxx,out_eSPA);
    k=1;
    for ind_t1=1:length(tt1);
        for ind_t2=1:length(tt2);
            M(ind_i(k),ind_j(k))=prob(ind_prob,k);
            I(ind_i(k),ind_j(k))=ind_i(k);
            J(ind_i(k),ind_j(k))=ind_j(k);
            k=k+1;
        end;
    end

    figure;imagesc(tt2,tt1,M);hold on;plot(X(ind(2)),X(ind(1)),'ro','LineWidth',3,'MarkerSize',20)
    set(gca,'FontSize',20,'LineWidth',2);
    set(gcf,'Position',[10 100 800  600]);
    xlabel(['Value of the feature ' num2str(ind(2))]);ylabel(['Value of the feature ' num2str(ind(1))]);
    title([TitleName ' ' num2str(t)]);
    caxis([0 1]);


end
%legend({'no default after 1 yr.','eSPA default probability']})
