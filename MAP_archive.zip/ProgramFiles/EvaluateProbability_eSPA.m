function prob=EvaluateProbability_eSPA(X,in)
W=in.W;
C=in.C;
W_m = sqrt(W);
X_W = bsxfun(@times,X,W_m);
C_W = bsxfun(@times,C,W_m);
K=size(in.C,2);
[d,T]=size(X);

[gamma] = SPACL_EvaluateGamma_valid(X_W,C_W,T,K);
prob=in.P*gamma;