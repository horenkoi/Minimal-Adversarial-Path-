function [ n,K ] = get_size_of_C( C )
% if someone is too lazy to write size(...)
% and the check of consistency of input variables
%

n = size(C,1);
K = size(C,2);

end

