function [X,Pi] = ClassifyRandomSeed(dim,T)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
K=1;dim_K=floor(T/K);
rng('default');
rand('seed',1)
X(:,1:T)=rand(T,dim)';
for k=1:K
rand('seed',k+1);
%rng('twister');
X=[X rand(dim_K,dim)'];
end

Pi(1,1:T)=1;
Pi(1,(1+T):2*T)=0;
Pi(2,:)=1-Pi(1,:);
