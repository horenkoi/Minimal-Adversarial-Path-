function S = SPA_FactorsSensitivity_v2(C)
% Computing S --> a (1xD)-Vector of eSPA Labels Sensitivities to D Features
% C - (DxK) matrix of K eSPA box centers in D factor dimensions
% W - D eSPA factor weight probabilities 
C_W=C;
[D,K]=size(C);

S=zeros(1,D);
for i=1:D
    for k1=1:K
        for k2=1:K
            S(i)=S(i)+(C_W(i,k1)-C_W(i,k2))^2;
        end
    end
end

end

