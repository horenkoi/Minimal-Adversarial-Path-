function MAD = MAD_RF(mdl,X,Delta,Data)

[~,Y] = predict(mdl,X');Y=Y(1);
D=size(Data,1);
D_inv=1./D;

[~,yy] = predict(mdl,Data');
y=yy(:,1)';
for t=1:size(Data,2)
    dist(t)=sum((X-Data(:,t)).^2); 
end

[~,ii]=find(abs(y-Y)>Delta);
[~,jj]=min(dist(ii));
X_start=Data(:,ii(jj(1)));

%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
woptions_fmincon = optimoptions(@fmincon,...
    'Algorithm','sqp',...
    'MaxIter',500,'HessianFcn',@(x,lambda)hessinterior(x,lambda,D,D_inv),'MaxFunctionEvaluations',1e6,...
    'Display','iter','TolFun',1e-9,'TolCon',1e-9,'TolPCG',1e-9,'TolX',...
    1e-9,'TolConSQP',1e-9,'TolGradCon',1e-9,'TolPCG',1e-9,...
    'OptimalityTolerance',1e-9,'StepTolerance',1e-9,'SpecifyObjectiveGradient',true);

        %[~,Y] = predict(mdl,X');Y=Y(1)
        x0=X_start;
        [x,MAD,flag,output] = fmincon(@(X_delta)AD(X_delta,X,D_inv),x0,...
            [],[],[],[],[],[],@(X_delta)mycon(X_delta,Y,mdl,Delta),woptions_fmincon);
        MAD 

end

function [ad,grad_ad] = AD(X_delta,X,D_inv)
%Y_delta = predict(mdl,X_delta);
ad=D_inv*sum((X-X_delta).^2);
grad_ad=2*D_inv*(X-X_delta);
end

function [c,ceq] = mycon(X_delta,Y,mdl,Delta)
[~,Y_delta] = predict(mdl,X_delta');Y_delta=Y_delta(1);
c=Delta-abs(Y_delta-Y(1));
ceq=[];
end

function H = hessinterior(X_delta,lambda,D,D_inv)
%HMFLEQ1 Hessian-matrix product function for BROWNVV objective.
%   W = hmfleq1(Hinfo,Y,V) computes W = (Hinfo-V*V')*Y
%   where Hinfo is a sparse matrix computed by BROWNVV 
%   and V is a 2 column matrix.
H=-2*D_inv*speye(D);

end

