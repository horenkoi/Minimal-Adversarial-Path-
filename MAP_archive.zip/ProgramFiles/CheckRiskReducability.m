function y=CheckRiskReducability(X, model, ind_control,label_control,flag)

prob_orig=EvaluateProbability_eSPA_full(X,model);
[~,ii]=sort(prob_orig(1,:));
K=size(model.C,2);
T=size(X,2);
y.sort_ind=ii;

for t=1:T
    t
    [obj]=FindVoronoiGraphSPA(model,ind_control,label_control,X(:,t),flag);
    G = digraph(obj.adj);
    Degr = 0.5*(indegree(G)+outdegree(G));
    ddd=find(Degr>0);
    y.connected(t)=length(ddd);
    y.degree(t)=mean(Degr(ddd));
    [bins,sizes] = conncomp(G,'Type','weak');
    y.largeconncomp(t)=max(sizes);
    for k=1:K
        dist(k)=norm(model.W.*(X(:,t)-model.C(:,k)),2);
    end
    [~,k]=min(dist);
    clear path1 d
     for k1=1:K
        [path1{k1},d(k1)] = shortestpath(G,k,k1);
        if ~isempty(path1{k1})
        prob_red(k1)=(obj.W(k)-obj.W(path1{k1}(end)));
        else
         prob_red(k1)=0;   
        end
     end
         [m_ii,ii]=max(prob_red);ii=find(prob_red==m_ii);
    [~,iii]=min(d(ii));ii=ii(iii);k2=ii;

    %[~,k2]=max(abs(prob_red));
    y.prob_red(t)=prob_red(ii);
    y.dist(t)=d(ii);
    y.path{t}=path1{ii};
    if prob_red(k2)<0
       keyboard
    end
end
end