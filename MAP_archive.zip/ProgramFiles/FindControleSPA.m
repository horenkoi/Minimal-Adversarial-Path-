function [x,dist,risk]=FindControleSPA(model,ind_control,label_control,X);
P=model.P_valid;
prob_X=EvaluateProbability_eSPA_full(X,model);

ii=1:size(P,2);%find(P(label_control,:)<prob_margin);
for k=1:size(model.C,2)
    n(k)=norm(X-model.C(:,k),"fro")^2;
end
[~,KK]=min(n);
H=2*eye(length(ind_control));
W=model.W;
%W=ones(size(W));
%W_m = sqrt(W);
%X_W=X.*W_m;
f=-2*X(ind_control);
options = optimoptions('quadprog','Algorithm','interior-point-convex','Display','off','MaxIterations',10000,'ConstraintTolerance',1e-12,'FunctionTolerance',1e-12);
x=[];dist=[];risk=[];
ind=1;
for i=setdiff(1:length(ii),KK)
    ppp=EvaluateProbability_eSPA_full(model.C(:,i),model);
    prob_C=ppp(label_control);
    [A,b]=ComputeBoundingPlanesofSimplex(model,ii(i),ind_control,X);
    [xx,fval,exitflag,output] = quadprog(H,f,A,b,[],[],zeros(length(ind_control),1),ones(length(ind_control),1),model.C(ind_control,ii(i)),options);
    if and(prob_C<prob_X,exitflag>0)
        x(ind,:)=(X');
        x(ind,ind_control)=(xx);
        dist(ind)=norm(X(ind_control,1)-xx,"fro")^2;
        %x(ind,:)=x(ind,:)./W_m';
        risk(ind)=P(label_control,ii(i));
        pp=EvaluateProbability_eSPA_full(x(ind,:)',model);prob_orig(ind)=pp(label_control);
        ind=ind+1;
    else
        %ii(i)
    end
end
